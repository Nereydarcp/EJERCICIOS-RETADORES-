superficie_km = 57365
tipos_climas = ["calido", "subhumedo", "seco", "semiseco"]
temperatura_media_anual = 25.45
precipitacion_promedio_mm = 790.1

poblacion_hombres = 1494815
poblacion_mujeres = 1532128
porcentaje_habitantes_culiacan = 33.15
porcentajehabitantes_mazatlan = 16.57

#porcentaje total
poblacion_total = poblacion_hombres + poblacion_mujeres
print(f"La poblacion total es: {poblacion_total}")

#porcentaje total entre Culican y Mazatlan
 
porcentaje_total_culiacan_mazatlan =porcentajehabitantes_culiacan + porcentajehabitantes_mazatlan
print(f"El procentaje total es: {porcentaje_totalCYM}")

#tipos de clima
print(f"Los tipos de climas son: {tipos_climas}")

#Temperatura media anual 
print(f"La temperatura media anual: {temperaturamediaanual}")